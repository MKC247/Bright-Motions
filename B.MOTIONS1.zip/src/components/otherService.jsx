import React from "react";

const OtherService = ()=>{
 return(
    <div>
         
    </div>
 )
}

export default OtherService;